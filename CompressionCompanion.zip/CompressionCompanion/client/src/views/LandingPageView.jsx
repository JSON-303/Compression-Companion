import LandingPage from '../components/LandingPage';

const LandingPageView = () => {
    return (
        <>
            <main>
                <LandingPage />
            </main>
        </>
    )
}

export default LandingPageView;