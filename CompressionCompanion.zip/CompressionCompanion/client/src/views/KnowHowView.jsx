import React from 'react';
import KnowHow from '../components/KnowHow';

const KnowHowView= () => {
    return (
        <>
            <main>
                <KnowHow />
            </main>
        </>
    );
};

export default KnowHowView;