import Authorization from '../components/LoginAndReg';

const LoginAndRegView = () => {
    return (
        <>
            <main>
                <Authorization />
            </main>
        </>
    )
}

export default LoginAndRegView;